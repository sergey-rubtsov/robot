﻿_______________________________________________________________________________
         Gowin_FOC Current Control TDM 参考设计阅读指南
----------------------------------------------------------------------
目标器件：GW2A-LV18PG484C8/I7
----------------------------------------------------------------------
文件列表
----------------------------------------------------------------------
.
| -- docs
|	`-- readme.txt									-->	自述文件
| -- project
|	|-- foc_current_loop_control
|	|	`-- foc_current_loop_control.gprj			-->	参考设计工程
|	|	|-- src
|	|	|  `-- top.v								-->	工程顶层模块
|	|	|  `-- Ia_prom.v							--> Ia Data ROM
|	|	|  `-- Ib_prom.v							--> Ib Data ROM
|	|	|  `-- Theta_prom.v							--> Theta Data ROM
|	|	|  `-- cordic_top.v							--> Cordic模块
|	|	|  `-- gw2a18.cst							--> 约束文件
|	|	|-- foc_current_loop_control_tdm
|	|	|  `-- foc_current_loop_control_tdm.ipc
|	|	|  `-- foc_current_loop_control_tdm.v
|	|	|  `-- foc_current_loop_control_tdm.vo	-->	仿真使用vo文件
|	|	|-- impl
| -- simulation
|	|-- lib
|	|  `-- prim_sim.v								-->	仿真原语库 			
|	|-- Modelsim				
|	|   `-- cmd.do									-->	modelsim仿真脚本
| -- tb				
|	|  `-- tb.v										-->	modelsim仿真testbench


----------------------------------------------------------------------
使用说明：
	1、板测：使用云源软件打开上述文件中foc_current_loop_control.gprj，设置工程顶层模块,综合；根据所使用器件设置约束后布局布线后下载测试。
	2、modelsim仿真：仿真脚本存放于Modelsim文件夹中

	注：lib文件夹下prim_sim.v仅供参考，建议用户根据情况在仿真时使用最新版替换。

_______________________________________________________________________________
        Example Gowin_PDM2PCM Design Readme
----------------------------------------------------------------------
Object device:GW2A-LV18PG484C8/I7
----------------------------------------------------------------------
File List:
----------------------------------------------------------------------
.
| -- docs
|	`-- readme.txt									-->	Read Me file (this file)
| -- project
|	|-- foc_current_loop_control				
| 	|	`--foc_current_loop_control.gprj			-->	Gowin Project File for Example Design
| 	|	|-- src
| 	|	|	`-- top.v								-->	File for Gowin Project
|	|	|  `-- Ia_prom.v							--> Ia Data ROM
|	|	|  `-- Ib_prom.v							--> Ib Data ROM
|	|	|  `-- Theta_prom.v							--> Theta Data ROM
|	|	|  `-- cordic_top.v							--> Cordic Module
|	|	|  `-- gw2a18.cst							--> Constriant file
| 	|	|-- foc_current_loop_control_light
| 	|	|   `-- foc_current_loop_control_light.ipc
| 	|	|   `-- foc_current_loop_control_light.v
| 	|	|   `-- foc_current_loop_control_light.vo	-->	Verilog simulation File for tb
| 	|	|-- impl	
| -- simulation	
|	|-- lib
|	|	`-- prim_sim.v								-->	Verilog functional simulation library
|	|-- Modelsim					
|	| 	`-- cmd.do									-->	modelsim simulation script
| -- tb					
|	|	`-- tb.v									-->	TestBench for modelsim simulation
----------------------------------------------------------------------
Instructions:
	1、Onboard test:Launch Gowin and select "File -> Open -> Project", set Top Module. After Sythesize, cofigure Physical Constraints.
	2、modelsim simulation:Use script in Modelsim folder.

	Note: The prim_sim.v under the tb folder is for reference only. It is recommended that users replace it with the latest version during simulation.